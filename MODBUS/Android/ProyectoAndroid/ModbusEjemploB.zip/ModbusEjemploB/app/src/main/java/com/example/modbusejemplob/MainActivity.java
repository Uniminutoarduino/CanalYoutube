package com.example.modbusejemplob;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.zgkxzx.modbus4And.requset.ModbusParam;
import com.zgkxzx.modbus4And.requset.ModbusReq;
import com.zgkxzx.modbus4And.requset.OnRequestBack;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    String TAG="Mensaje Modbus";//TAG para mensajes de modbus
    ModbusReq Conexion = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button Activar=findViewById(R.id.button);
        Activar.setOnClickListener(this);
        Button Desactivar=findViewById(R.id.button2);
        Desactivar.setOnClickListener(this);
        Button Activarcoil=findViewById(R.id.button3);//Botón para activa coil
        Activarcoil.setOnClickListener(this);
        Button Desactivarcoil=findViewById(R.id.button4);//Boton para desactivar coil
        Desactivarcoil.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        final TextView Texto=findViewById(R.id.Texto1);
        if(v.getId()==R.id.button){
            //Crear conexión Modbus con la IP del ESP32
            Conexion.getInstance().setParam(new ModbusParam()
                    .setHost("192.168.0.101")
                    .setPort(502)
                    .setEncapsulated(false)
                    .setKeepAlive(true)
                    .setTimeout(2000)
                    .setRetries(2))
                    .init(new OnRequestBack<String>() {
                        @Override
                        public void onSuccess(String s) {

                            //Log.d("Acceso correcto", "onSuccess " + s);
                            Texto.setText("Estado: Conectado");//Crear texto conectado si se realiza la conexión modbus

                        }

                        @Override
                        public void onFailed(String msg) {
                            //Log.d("Acceso errado", "onFailed " + msg);
                            Texto.setText("Error..."); //Eror en etiqueta
                        }
                    });
        }else if(v.getId()==R.id.button2){//Desconectar
            Texto.setText("Desconectado...");
            Conexion.getInstance().destory();//Destruir instancia de acceso a MODBUS
        }else if (v.getId()==R.id.button3){//Activar coil
            ModbusReq.getInstance().writeCoil(new OnRequestBack<String>() {
                @Override
                public void onSuccess(String s) {
                    //Log.e(TAG, "Escritura exitosa " + s);
                    Texto.setText("Estado: Coil encendido");
                }

                @Override
                public void onFailed(String msg) {
                   // Log.e(TAG, "Escritura con error " + msg);
                    Texto.setText("Escritura con error ");
                }
            },1,100,false);//Se apunta a la dirección 100 donde esta el registro para el coil. False en el modulo rele es encender

        }else if(v.getId()==R.id.button4){//Desactivar coil
            ModbusReq.getInstance().writeCoil(new OnRequestBack<String>() {
                @Override
                public void onSuccess(String s) {
                    //Log.e(TAG, "Escritura exitosa " + s);
                    Texto.setText("Estado: Coil apagado");
                }

                @Override
                public void onFailed(String msg) {
                    //Log.e(TAG, "Escritura con error " + msg);
                    Texto.setText("Escritura con error ");
                }
            },1,100,true);//Se apunta a la dirección 100 donde esta el registro para el coil. True en el modulo rele es apagar

        }
    }
}
